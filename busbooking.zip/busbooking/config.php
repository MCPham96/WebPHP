<?php
	$dbServer = 'localhost';
	$dbUsername = 'root';
	$dbPassword = '';
	$dbDatabase = 'busbooking';

	$adminConfig = array(
		'adminUsername' => "admin",
		'adminPassword' => "5a1760628ea739e61d9bb798b50542d5",
		'notifyAdminNewMembers' => "0",
		'defaultSignUp' => "1",
		'anonymousGroup' => "anonymous",
		'anonymousMember' => "hacker",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "1000",
		'custom2' => "1000",
		'custom3' => "1000",
		'custom4' => "1000",
		'MySQLDateFormat' => "%m/%d/%Y",
		'PHPDateFormat' => "n/j/Y",
		'PHPDateTimeFormat' => "m/d/Y, h:i a",
		'senderName' => "Quản lý thành viên",
		'senderEmail' => "admin@admin.com",
		'approvalSubject' => "Tư cách thành viên của bạn đã được phê duyệt",
		'approvalMessage' => "Kính gửi thành viên, \ r \ n \ r \ n Thành viên của bạn hiện đã được quản trị viên phê duyệt. Bạn có thể đăng nhập vào tài khoản của mình tại đây: \ r \ nhttp: // localhost / busbooking \ r \ n \ r \ nRegards, \ r \ nAdmi",
		'hide_twitter_feed' => "1",
		'maintenance_mode_message' => "<b> Trang web của chúng tôi hiện đang ngừng hoạt động để bảo trì </ b> <br> \ r \ n Chúng tôi dự kiến ​​sẽ hoạt động trở lại sau vài giờ nữa. Cảm ơn sự kiên nhẫn của bạn.",
		'mail_function' => "mail",
		'smtp_server' => "",
		'smtp_encryption' => "",
		'smtp_port' => "25",
		'smtp_user' => "",
		'smtp_pass' => ""
	);